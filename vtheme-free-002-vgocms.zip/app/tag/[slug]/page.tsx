import { Metadata } from 'next';
import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { getSiteVideos, getTagSeo } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import Pagination from '@/components/ui/Pagination';
import TaxonomyLoading from '../loading';

import { constructMetadata } from '@/lib/seo';
import { getImageUrl } from '@/lib/utils';

export async function generateMetadata(
  props: { params: Promise<{ slug: string }>, searchParams: Promise<{ [key: string]: string | string[] | undefined }> }
): Promise<Metadata> {
  const { slug } = await props.params;
  const sParams = await props.searchParams;

  const queryParams: Record<string, string | number> = { tag: slug };
  ['page', 'limit', 'sort'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const [videosRes, tagSeo] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getTagSeo(slug).catch(() => null)
  ]);

  const seo = videosRes?.seo;
  const displayName = tagSeo?.name || slug;

  return constructMetadata(
    seo,
    tagSeo?.seo_title || `Phim Tag: ${displayName} | Video Site`,
    `Danh sách phim liên quan đến tag ${displayName}.`
  );
}

async function TagContent({
  slug,
  sParams
}: {
  slug: string;
  sParams: { [key: string]: string | string[] | undefined };
}) {
  // Try to get tag info for display
  const tagSeo = await getTagSeo(slug).catch(() => null);
  const displayTitle = tagSeo?.name || slug;

  const queryParams: Record<string, string | number> = {
    tag: slug,
  };

  ['page', 'limit', 'sort'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const currentPage = parseInt(queryParams.page as string || '1');
  const videosRes = await getSiteVideos(queryParams).catch(() => null);
  const videosData = videosRes?.success ? videosRes.data : null;

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const currentUrl = `${siteUrl}/tag/${slug}${currentPage > 1 ? `?page=${currentPage}` : ''}`;

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": `${currentUrl}#webpage`,
        "url": currentUrl,
        "name": `Tag: ${displayTitle} - Trang ${currentPage}`,
        "description": `Danh sách phim liên quan đến tag ${displayTitle}.`,
        "isPartOf": {
          "@id": `${siteUrl}/#website`
        },
        "breadcrumb": {
          "@id": `${currentUrl}#breadcrumb`
        }
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${currentUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "item": {
              "@id": `${siteUrl}/`,
              "name": "Trang Chủ"
            }
          },
          {
            "@type": "ListItem",
            "position": 2,
            "item": {
              "@id": `${siteUrl}/tag/${slug}`,
              "name": displayTitle
            }
          }
        ]
      },
      ...(videosData && videosData.items && videosData.items.length > 0 ? [{
        "@type": "ItemList",
        "@id": `${currentUrl}#itemlist`,
        "name": `Danh sách phim tag ${displayTitle}`,
        "itemListElement": videosData.items.map((video: any, index: number) => ({
          "@type": "ListItem",
          "position": index + 1,
          "item": {
            "@type": video.episode_count > 1 ? "TVSeries" : "Movie",
            "url": `${siteUrl}/phim/${video.slug}`,
            "name": video.title,
            "image": getImageUrl(video.thumb || video.poster),
            ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {}),
            ...(video.directors && video.directors.length > 0 ? {
              "director": video.directors.map((d: any) => ({
                "@type": "Person",
                "name": d.name
              }))
            } : {})
          }
        }))
      }] : [])
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
        Tag: {displayTitle}
      </h1>

      {videosData && videosData.items && videosData.items.length > 0 ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {videosData.items.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={videosData.total_pages}
            basePath={`/tag/${slug}`}
            searchParams={sParams}
          />
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center">
          <p className="text-gray-500 text-lg">Chưa có phim nào liên quan đến thẻ này.</p>
        </div>
      )}
    </>
  );
}

export default async function TagPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { slug } = await params;
  const sParams = await searchParams;
  const suspenseKey = JSON.stringify(sParams);

  return (
    <Suspense key={suspenseKey} fallback={<TaxonomyLoading />}>
      <TagContent slug={slug} sParams={sParams} />
    </Suspense>
  );
}
