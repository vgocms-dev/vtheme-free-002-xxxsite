export default function PersonLoading() {
  return (
    <div className="space-y-8">
      {/* Breadcrumb Skeleton */}
      <nav className="flex items-center gap-1">
        <div className="h-4 w-16 skeleton rounded"></div>
        <span className="text-gray-400">/</span>
        <div className="h-4 w-24 skeleton rounded"></div>
      </nav>

      {/* Profile Section Skeleton */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 flex flex-col sm:flex-row gap-6 items-start">
        {/* Avatar Skeleton */}
        <div className="relative w-32 h-32 sm:w-48 sm:h-48 rounded-full skeleton shadow-md border-4 border-gray-100 dark:border-gray-700 mx-auto sm:mx-0 shrink-0"></div>

        <div className="flex-1 text-center sm:text-left space-y-4 w-full">
          <div className="h-9 w-48 sm:w-64 skeleton rounded-lg mx-auto sm:mx-0"></div>
          <div className="space-y-2">
            <div className="h-4 w-32 skeleton rounded mx-auto sm:mx-0"></div>
            <div className="h-4 w-24 skeleton rounded mx-auto sm:mx-0"></div>
            <div className="h-4 w-28 skeleton rounded mx-auto sm:mx-0"></div>
          </div>

          <div className="space-y-2 pt-2">
            <div className="h-4 w-full skeleton rounded"></div>
            <div className="h-4 w-full skeleton rounded"></div>
            <div className="h-4 w-3/4 skeleton rounded"></div>
          </div>
        </div>
      </div>

      {/* Videos Section Skeleton */}
      <div>
        <div className="h-8 w-64 skeleton rounded-lg mb-6 border-l-4 border-transparent pl-3"></div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="space-y-3">
              <div className="aspect-video skeleton rounded-lg w-full"></div>
              <div className="h-4 w-full skeleton rounded"></div>
              <div className="h-4 w-2/3 skeleton rounded"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
