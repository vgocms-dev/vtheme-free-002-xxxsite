import { Metadata } from 'next';
import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { getSiteVideos, getSiteTaxonomies, getSiteAds } from '@/lib/api';
import VideoCard from '@/components/video/VideoCard';
import VideoFilters from '@/components/video/VideoFilters';
import Pagination from '@/components/ui/Pagination';
import AdSlot from '@/components/layout/AdSlot';
import TaxonomyLoading from '../loading';

import { constructMetadata } from '@/lib/seo';
import { getImageUrl } from '@/lib/utils';

export async function generateMetadata(
  props: { params: Promise<{ year: string }>, searchParams: Promise<{ [key: string]: string | string[] | undefined }> }
): Promise<Metadata> {
  const { year } = await props.params;
  const sParams = await props.searchParams;

  if (!/^\d{4}$/.test(year)) {
    return { title: 'Năm sản xuất không hợp lệ' };
  }

  const queryParams: Record<string, string | number> = { year: year };
  ['page', 'limit', 'sort', 'kind', 'category', 'country', 'format', 'server'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const videosRes = await getSiteVideos(queryParams).catch(() => null);
  const seo = videosRes?.seo;

  return constructMetadata(
    seo,
    `Phim năm ${year} | Video Site`,
    `Danh sách phim hay phát hành năm ${year}, cập nhật liên tục.`
  );
}

async function NamSanXuatContent({
  year,
  sParams
}: {
  year: string;
  sParams: { [key: string]: string | string[] | undefined };
}) {
  const queryParams: Record<string, string | number> = {
    year: year,
  };

  // Merge the rest of the search params (like page, sort, kind, etc)
  ['page', 'limit', 'sort', 'kind', 'category', 'country', 'format', 'server'].forEach(key => {
    if (sParams[key]) queryParams[key] = sParams[key] as string;
  });

  const currentPage = parseInt(queryParams.page as string || '1');

  // Fetch videos and taxonomies (for filters) in parallel
  const [videosRes, taxonomiesRes, adsRes] = await Promise.all([
    getSiteVideos(queryParams).catch(() => null),
    getSiteTaxonomies().catch(() => null),
    getSiteAds().catch(() => [])
  ]);

  const videosData = videosRes?.success ? videosRes.data : null;
  const taxonomies = taxonomiesRes?.success ? taxonomiesRes.data : {};
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);

  const siteUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';
  const currentUrl = `${siteUrl}/nam-san-xuat/${year}${currentPage > 1 ? `?page=${currentPage}` : ''}`;

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": `${currentUrl}#webpage`,
        "url": currentUrl,
        "name": `Phim Năm Phát Hành: ${year} - Trang ${currentPage}`,
        "description": `Danh sách phim hay phát hành năm ${year}, cập nhật liên tục.`,
        "isPartOf": {
          "@id": `${siteUrl}/#website`
        },
        "breadcrumb": {
          "@id": `${currentUrl}#breadcrumb`
        }
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${currentUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "item": {
              "@id": `${siteUrl}/`,
              "name": "Trang Chủ"
            }
          },
          {
            "@type": "ListItem",
            "position": 2,
            "item": {
              "@id": `${siteUrl}/nam-san-xuat/${year}`,
              "name": year
            }
          }
        ]
      },
      ...(videosData && videosData.items && videosData.items.length > 0 ? [{
        "@type": "ItemList",
        "@id": `${currentUrl}#itemlist`,
        "name": `Danh sách phim năm ${year}`,
        "itemListElement": videosData.items.map((video: any, index: number) => ({
          "@type": video.episode_count > 1 ? "TVSeries" : "Movie",
          "url": `${siteUrl}/phim/${video.slug}`,
          "name": video.title,
          "image": getImageUrl(video.thumb || video.poster),
          ...(video.created_at ? { "dateCreated": new Date(video.created_at).toISOString() } : {}),
          ...(video.directors && video.directors.length > 0 ? {
            "director": video.directors.map((d: any) => ({
              "@type": "Person",
              "name": d.name
            }))
          } : {})
        }))
      }] : [])
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-l-4 border-blue-500 pl-3">
        Phim Năm Phát Hành: {year}
      </h1>

      <VideoFilters
        categories={taxonomies.category || []}
        countries={taxonomies.country || []}
        servers={taxonomies.server || []}
        formats={taxonomies.format || []}
        kinds={taxonomies.kind || []}
      />

      <div>
        <AdSlot position="listing_top" ads={ads} />
      </div>

      {videosData && videosData.items && videosData.items.length > 0 ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-6">
            {videosData.items.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={videosData.total_pages}
            basePath={`/nam-san-xuat/${year}`}
            searchParams={sParams}
          />
        </>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow text-center mt-6">
          <p className="text-gray-500 text-lg">Chưa có phim nào phát hành vào năm {year}.</p>
        </div>
      )}

      <div>
        <AdSlot position="listing_bottom" ads={ads} />
      </div>
    </>
  );
}

export default async function NamSanXuatPage({
  params,
  searchParams,
}: {
  params: Promise<{ year: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { year } = await params;
  const sParams = await searchParams;

  if (!/^\d{4}$/.test(year)) {
    notFound();
  }

  const suspenseKey = JSON.stringify(sParams);

  return (
    <Suspense key={suspenseKey} fallback={<TaxonomyLoading />}>
      <NamSanXuatContent year={year} sParams={sParams} />
    </Suspense>
  );
}
