export default function HomeLoading() {
  return (
    <div className="space-y-12">
      {/* Phim Mới Nhất Skeleton */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <div className="h-8 w-48 skeleton rounded-lg"></div>
          <div className="h-4 w-24 skeleton rounded"></div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="space-y-3">
              <div className="aspect-video skeleton rounded-lg"></div>
              <div className="h-4 w-3/4 skeleton rounded"></div>
            </div>
          ))}
        </div>
      </section>

      {/* Top Phim Hot Tuần Skeleton */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <div className="h-8 w-48 skeleton rounded-lg"></div>
          <div className="h-4 w-24 skeleton rounded"></div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-5">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="aspect-video skeleton rounded-xl"></div>
          ))}
        </div>
      </section>
    </div>
  );
}
