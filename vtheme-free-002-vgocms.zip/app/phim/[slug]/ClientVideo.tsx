'use client';

import { useState, useEffect } from 'react';
import { EpisodeInput, ServerEpisode, VideoDetail, VideoItem } from '@/lib/types';
import VideoPlayer from '@/components/video/VideoPlayer';
import EpisodeList from '@/components/video/EpisodeList';
import VideoCard from '@/components/video/VideoCard';
import AdSlot from '@/components/layout/AdSlot';
import { postView, postRate } from '@/lib/api';
import { getTmdbUrl } from '@/lib/utils';
import Image from 'next/image';
import Link from 'next/link';
import { getImageUrl, naturalCompare } from '@/lib/utils';
import { useMemo } from 'react';

interface ClientVideoProps {
  video: VideoDetail;
  serverEpisodes: ServerEpisode[];
  ads?: any[];
  relatedVideos?: VideoItem[];
}

export default function ClientVideo({ video, serverEpisodes: rawServerEpisodes = [], ads = [], relatedVideos = [] }: ClientVideoProps) {
  const sortedServers = useMemo(() => {
    if (!Array.isArray(rawServerEpisodes)) return [];

    return [...rawServerEpisodes]
      .map(srv => ({
        ...srv,
        server_data: Array.isArray(srv.server_data)
          ? [...srv.server_data].sort((a, b) => naturalCompare(a.name || '', b.name || ''))
          : []
      }));
  }, [rawServerEpisodes]);

  const [currentEpisode, setCurrentEpisode] = useState<EpisodeInput | undefined>(() => {
    return sortedServers.length > 0 && sortedServers[0]?.server_data?.length
      ? sortedServers[0].server_data[0]
      : undefined;
  });
  const [likes, setLikes] = useState<number>(video.likes || 0);
  const [dislikes, setDislikes] = useState<number>(video.dislikes || 0);
  const [views, setViews] = useState<number>(video.views || 0);

  const totalRating = likes + dislikes;
  const score = totalRating > 0 ? Math.round((likes / totalRating) * 100) / 10 : 5;

  // Sync state with props and localStorage in case of NextJS fast refresh or cache issues
  useEffect(() => {
    // Sync likes/dislikes
    let currentLikes = video.likes || 0;
    let currentDislikes = video.dislikes || 0;

    const cachedLikes = localStorage.getItem(`video_${video.id}_likes`);
    if (cachedLikes && parseInt(cachedLikes) > currentLikes) {
      currentLikes = parseInt(cachedLikes);
    }

    const cachedDislikes = localStorage.getItem(`video_${video.id}_dislikes`);
    if (cachedDislikes && parseInt(cachedDislikes) > currentDislikes) {
      currentDislikes = parseInt(cachedDislikes);
    }

    setLikes(currentLikes);
    setDislikes(currentDislikes);
  }, [video.id, video.likes, video.dislikes]);

  useEffect(() => {
    // Record view on mount
    postView(video.id).then(res => {
      if (res.success) setViews(res.views);
    }).catch(() => { });
  }, [video.id]);

  const handleRate = async (action: 'like' | 'dislike') => {
    // UI "troll" / Optimistic Update: Cập nhật ngay trên màn hình và lưu vào LocalStorage
    if (action === 'like') {
      setLikes(prev => {
        const newLikes = prev + 1;
        localStorage.setItem(`video_${video.id}_likes`, newLikes.toString());
        return newLikes;
      });
    } else {
      setDislikes(prev => {
        const newDislikes = prev + 1;
        localStorage.setItem(`video_${video.id}_dislikes`, newDislikes.toString());
        return newDislikes;
      });
    }

    try {
      const res = await postRate(video.id, action);
      if (res.success) {
        // Ignored to keep the troll count
      } else {
        console.warn('Backend rejected rate:', (res as any).error);
      }
    } catch (e: any) {
      console.error('Rate Error:', e.message);
    }
  };

  return (
    <div className="space-y-8">
      {/* Quảng cáo trên Player Section */}
      {ads?.some(a => a.position === 'video_before_play') && (
        <div>
          <AdSlot position="video_before_play" ads={ads} />
        </div>
      )}

      {/* Player Section */}
      <div className="bg-gray-950 -mx-4 sm:mx-0 sm:rounded-xl overflow-hidden shadow-2xl">
        <VideoPlayer
          episode={currentEpisode}
          hasEpisodes={sortedServers?.some((s: ServerEpisode) => (s.server_data?.length ?? 0) > 0)}
        />
      </div>

      {/* Quảng cáo dưới Player Section */}
      {ads?.some(a => a.position === 'video_pause') && (
        <div>
          <AdSlot position="video_pause" ads={ads} />
        </div>
      )}

      {/* Episode List */}
      <div className="mt-6">
        <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-gray-100 flex items-center gap-2">
          <span className="bg-blue-600 w-1.5 h-6 rounded-full inline-block"></span>
          Danh sách tập phim
        </h3>
        <EpisodeList
          servers={sortedServers}
          onSelectEpisode={setCurrentEpisode}
          currentEpisode={currentEpisode}
          fallbackThumb={video.thumb || video.poster}
        />
      </div>

      {/* Video Details */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 mt-8 border border-gray-100 dark:border-gray-700">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-full max-w-[200px] md:w-1/4 md:max-w-[220px] shrink-0 mx-auto md:mx-0 md:sticky md:top-20 md:self-start">
            <div className="relative w-full aspect-[2/3] rounded-lg overflow-hidden shadow-md">
              <Image
                src={getImageUrl(video.poster || video.thumb)}
                alt={video.title}
                fill
                sizes="(max-width: 768px) 200px, 220px"
                className="object-cover"
              />
            </div>
            <div className="flex flex-col gap-3 mt-4">
              <div className="flex items-center justify-center gap-2 py-2 px-3 bg-amber-500/10 dark:bg-amber-500/20 rounded-lg">
                <span className="text-amber-800 dark:text-amber-400 font-bold text-lg">★ {score}/10</span>
                {totalRating > 0 && (
                  <span className="text-xs text-gray-700 dark:text-gray-400" title={`${likes} thích / ${dislikes} không thích`}>
                    ({totalRating} đánh giá)
                  </span>
                )}
              </div>
              <div className="flex justify-between items-center gap-2">
                <button
                  onClick={() => handleRate('like')}
                  aria-label="Thích phim này"
                  className="flex-1 flex items-center justify-center gap-1 text-green-700 hover:text-green-800 font-bold px-2 py-2 bg-green-50 dark:bg-green-900/20 rounded transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7 10v12" />
                    <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
                  </svg>
                  {likes}
                </button>
                <span className="flex-1 flex items-center justify-center gap-1 text-gray-700 dark:text-gray-300 font-medium px-2 py-2 bg-gray-100 dark:bg-gray-700 rounded" aria-label={`${views} lượt xem`}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                  {views}
                </span>

                <button
                  onClick={() => handleRate('dislike')}
                  aria-label="Không thích phim này"
                  className="flex-1 flex items-center justify-center gap-1 text-red-700 hover:text-red-800 font-bold px-2 py-2 bg-red-50 dark:bg-red-900/20 rounded transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17 14V2" />
                    <path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z" />
                  </svg>
                  {dislikes}
                </button>
              </div>
            </div>
          </div>
          <div className="w-full min-w-0">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center flex-wrap gap-3">
              {video.title}
              {(video.formats?.length ?? 0) > 0 && (
                <span className="inline-flex flex-wrap gap-1.5">
                  {(video.formats ?? []).map(f => (
                    f.slug ? (
                      <Link key={f.id} href={`/dinh-dang/${f.slug}`} className="inline-block bg-yellow-500/10 text-yellow-800 dark:bg-yellow-500/20 dark:text-yellow-400 text-sm font-semibold px-2.5 py-1 rounded hover:bg-yellow-500/20 dark:hover:bg-yellow-500/30 transition-colors">
                        {f.lang_name || f.name}
                      </Link>
                    ) : (
                      <span key={f.id} className="inline-block bg-yellow-500/10 text-yellow-800 dark:bg-yellow-500/20 dark:text-yellow-400 text-sm font-semibold px-2.5 py-1 rounded">
                        {f.lang_name || f.name}
                      </span>
                    )
                  ))}
                </span>
              )}
            </h1>
            <p className="text-gray-700 dark:text-gray-400 mb-6 font-semibold">{video.original_name}</p>

            {/* Trạng thái & badges */}
            <div className="flex flex-wrap gap-2 mb-4">
              {video.release_status && (
                <span className={`inline-flex px-2.5 py-1 rounded text-xs font-medium ${video.release_status === 'releasing' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
                  video.release_status === 'upcoming' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400' :
                    'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                  }`}>
                  {video.release_status === 'releasing' ? 'Đang phát hành' : video.release_status === 'upcoming' ? 'Chưa ra mắt' : 'Hoàn Thành'}
                </span>
              )}
              {video.in_cinema && (
                <span className="inline-flex px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400">
                  Chiếu rạp
                </span>
              )}
              {(video.episode_count ?? 0) > 0 && (
                <span className="inline-flex px-2.5 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                  Tập {video.current_episode ?? 0}/{video.episode_count ?? 0}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 mb-6 text-sm">
              <div className="flex">
                <span className="text-gray-500 w-24 shrink-0">Năm sản xuất:</span>
                <span className="font-medium text-gray-800 dark:text-gray-200">
                  {video.year > 0 ? (
                    <Link href={`/nam-san-xuat/${video.year}`} className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 mr-2">
                      {video.year}
                    </Link>
                  ) : 'Đang cập nhật'}
                </span>
              </div>
              <div className="flex">
                <span className="text-gray-500 w-24 shrink-0 mt-1">Thể loại:</span>
                <span className="font-medium text-gray-800 dark:text-gray-200 flex flex-wrap gap-2 items-center">
                  {video.categories?.map(c => (
                    <Link key={c.id} href={`/the-loai/${c.slug}`} className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 hover:bg-purple-200 dark:hover:bg-gray-600 transition-colors">
                      {c.lang_name || c.name}
                    </Link>
                  ))}
                </span>
              </div>
              <div className="flex">
                <span className="text-gray-500 w-24 shrink-0 mt-1">Kiểu phim:</span>
                <span className="font-medium text-gray-800 dark:text-gray-200 flex flex-wrap gap-2 items-center">
                  {video.kind ? (
                    <Link href={`/kieu-phim/${video.kind.slug}`} className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 hover:bg-purple-200 dark:hover:bg-gray-600 transition-colors">
                      {video.kind.lang_name || video.kind.name}
                    </Link>
                  ) : 'Đang cập nhật'}
                </span>
              </div>
              <div className="flex">
                <span className="text-gray-700 dark:text-gray-400 w-24 shrink-0 mt-1">Quốc gia:</span>
                <span className="font-medium text-gray-900 dark:text-gray-200 flex flex-wrap gap-2 items-center">
                  {video.countries?.map(c => (
                    <Link key={c.id} href={`/quoc-gia/${c.slug}`} className="px-2.5 py-1 rounded text-xs font-semibold bg-purple-100 text-gray-900 dark:bg-gray-700 dark:text-gray-300 hover:bg-purple-200 dark:hover:bg-gray-600 transition-colors">
                      {c.lang_name || c.name}
                    </Link>
                  ))}
                </span>
              </div>
              {(video.formats?.length ?? 0) > 0 && (
                <div className="flex">
                  <span className="text-gray-500 w-24 shrink-0 mt-1">Chất lượng:</span>
                  <span className="font-medium text-gray-800 dark:text-gray-200 flex flex-wrap gap-2 items-center">
                    {(video.formats ?? []).map(f => (
                      f.slug ? (
                        <Link key={f.id} href={`/dinh-dang/${f.slug}`} className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 hover:bg-purple-200 dark:hover:bg-gray-600 transition-colors">
                          {f.lang_name || f.name}
                        </Link>
                      ) : (
                        <span key={f.id} className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                          {f.lang_name || f.name}
                        </span>
                      )
                    ))}
                  </span>
                </div>
              )}
              {(video.avg_duration ?? 0) > 0 && (
                <div className="flex">
                  <span className="text-gray-500 w-24 shrink-0">Thời lượng:</span>
                  <span className="px-2.5 py-1 rounded text-xs font-medium bg-purple-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 mr-2">
                    {video.avg_duration} phút
                  </span>
                </div>
              )}
              {video.tags && video.tags.length > 0 && (
                <div className="flex col-span-full">
                  <span className="text-gray-700 dark:text-gray-400 w-24 shrink-0 mt-1">Tags:</span>
                  <span className="font-medium text-gray-900 dark:text-gray-200 flex flex-wrap gap-2">
                    {video.tags.map(t => (
                      <Link key={t.id} href={`/tag/${t.slug}`} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-xs hover:text-blue-700 font-semibold transition-colors">
                        #{t.name}
                      </Link>
                    ))}
                  </span>
                </div>
              )}
              {(video.tmdb_id || video.imdb_id) && (
                <div className="flex col-span-full gap-4">
                  {video.tmdb_id && (
                    <a href={getTmdbUrl(video.tmdb_id)} target="_blank" rel="noopener noreferrer"
                      className="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300">
                      TMDB ↗
                    </a>
                  )}
                  {video.imdb_id && (
                    <a href={`https://www.imdb.com/title/${video.imdb_id.startsWith('tt') ? video.imdb_id : 'tt' + video.imdb_id}`} target="_blank" rel="noopener noreferrer"
                      className="text-sm font-medium text-amber-600 hover:text-amber-700 dark:text-amber-400 dark:hover:text-amber-300">
                      IMDB ↗
                    </a>
                  )}
                </div>
              )}
            </div>

            {/* Diễn viên & Đạo diễn */}
            {((video.actors?.length ?? 0) > 0 || (video.directors?.length ?? 0) > 0) && (
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-3 text-lg">Diễn viên & Đạo diễn</h4>
                <div className="flex flex-col gap-6">
                  {(video.actors?.length ?? 0) > 0 && (
                    <div>
                      <h5 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                        Diễn viên ({video.actors!.length})
                      </h5>
                      <div className="scrollbar-compact flex gap-3 overflow-x-auto overflow-y-hidden pb-2 min-w-0">
                        {video.actors!.map((a, i) => (
                          <Link
                            key={a.slug + '-' + i}
                            href={`/ngoi-sao/${a.slug}`}
                            className="flex flex-col items-center w-14 sm:w-16 shrink-0 group"
                          >
                            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full overflow-hidden bg-gray-200 dark:bg-gray-700 shrink-0 ring-2 ring-transparent group-hover:ring-blue-500 transition-all">
                              {a.avatar ? (
                                <Image
                                  src={getImageUrl(a.avatar)}
                                  alt={a.name}
                                  fill
                                  sizes="56px"
                                  className="object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400 text-sm font-bold">
                                  {(a.name || '?')[0].toUpperCase()}
                                </div>
                              )}
                            </div>
                            <span className="mt-1.5 text-xs font-medium text-gray-800 dark:text-gray-200 group-hover:text-blue-500 text-center line-clamp-2 max-w-[3.5rem] sm:max-w-16" title={a.name}>
                              {a.name}
                            </span>
                            {a.role && (
                              <span className="text-[10px] text-gray-500 dark:text-gray-400 text-center line-clamp-2 max-w-[3.5rem] sm:max-w-16" title={a.role}>
                                {a.role}
                              </span>
                            )}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                  {(video.directors?.length ?? 0) > 0 && (
                    <div>
                      <h5 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Đạo diễn</h5>
                      <div className="scrollbar-compact flex gap-3 overflow-x-auto overflow-y-hidden pb-2 min-w-0">
                        {video.directors!.map((d, i) => (
                          <Link
                            key={d.slug + '-' + i}
                            href={`/ngoi-sao/${d.slug}`}
                            className="flex flex-col items-center w-14 sm:w-16 shrink-0 group"
                          >
                            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full overflow-hidden bg-gray-200 dark:bg-gray-700 shrink-0 ring-2 ring-transparent group-hover:ring-blue-500 transition-all">
                              {d.avatar ? (
                                <Image
                                  src={getImageUrl(d.avatar)}
                                  alt={d.name}
                                  fill
                                  sizes="56px"
                                  className="object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400 text-sm font-bold">
                                  {(d.name || '?')[0].toUpperCase()}
                                </div>
                              )}
                            </div>
                            <span className="mt-1.5 text-xs font-medium text-gray-800 dark:text-gray-200 group-hover:text-blue-500 text-center line-clamp-2 max-w-[3.5rem] sm:max-w-16" title={d.name}>
                              {d.name}
                            </span>
                            {d.role && (
                              <span className="text-[10px] text-gray-500 dark:text-gray-400 text-center line-clamp-2 max-w-[3.5rem] sm:max-w-16" title={d.role}>
                                {d.role}
                              </span>
                            )}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Trailer */}
            {video.trailer_url && (
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Trailer</h4>
                <div className="aspect-video max-w-2xl rounded-lg overflow-hidden bg-black">
                  <iframe
                    src={(() => {
                      const u = video.trailer_url!;
                      if (u.includes('/embed/')) return u;
                      const m = u.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&?/]+)/);
                      return m ? `https://www.youtube.com/embed/${m[1]}` : u;
                    })()}
                    title="Trailer"
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              </div>
            )}
            <div className="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-300">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2 text-lg">Nội dung phim</h4>
              <div dangerouslySetInnerHTML={{ __html: video.description || '<p>Đang cập nhật nội dung...</p>' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Phim liên quan */}
      {relatedVideos.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-gray-100 flex items-center gap-2">
            <span className="bg-blue-600 w-1.5 h-6 rounded-full inline-block"></span>
            Phim liên quan
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {relatedVideos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
