import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Header, Footer } from '@/components/layout/Layout';
import Image from 'next/image';
import { getSiteSettings, getSiteAds, getSiteVideos } from '@/lib/api';
import AdSlot from '@/components/layout/AdSlot';
import { getImageUrl } from '@/lib/utils';
import Link from 'next/link';

const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export async function generateMetadata(): Promise<Metadata> {
  const settingsRes = await getSiteSettings().catch(() => null);
  const settings = settingsRes?.success ? settingsRes.data : null;
  const seo = settings?.seo;

  return {
    metadataBase: new URL(process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000'),
    title: seo?.title || settings?.seo_title || settings?.name || 'Video Site',
    description: seo?.description || settings?.seo_description || settings?.description || 'Video entertainment',
    keywords: seo?.keywords || settings?.seo_keywords || 'video, movies, series',
    robots: 'index, follow',
    icons: {
      icon: settings?.favicon_url || '/favicon.ico',
    },
    openGraph: {
      title: seo?.og_title || seo?.title || settings?.name,
      description: seo?.og_description || seo?.description || settings?.description,
      images: seo?.og_image ? [seo.og_image] : [],
      type: (seo?.og_type as any) || 'website',
    },
    twitter: {
      card: (seo?.twitter_card as any) || 'summary_large_image',
      title: seo?.og_title || seo?.title || settings?.name,
      description: seo?.og_description || seo?.description || settings?.description,
      images: seo?.og_image ? [seo.og_image] : [],
    },
    other: {
      'custom-head': settings?.custom_head_html || '',
    }
  };
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [settingsRes, adsRes, hotVideosRes, latestVideosRes, topRatedVideosRes] = await Promise.all([
    getSiteSettings().catch(() => null),
    getSiteAds().catch(() => []),
    getSiteVideos({ sort: 'view', limit: 6 }).catch(() => null),
    getSiteVideos({ sort: 'latest', limit: 6 }).catch(() => null),
    getSiteVideos({ sort: 'likes', limit: 6 }).catch(() => null),
  ]);
  const settings = settingsRes?.success ? settingsRes.data : null;
  const ads = Array.isArray(adsRes) ? adsRes : (adsRes?.data || []);
  const hotVideos = hotVideosRes?.success ? hotVideosRes.data.items : [];
  const latestVideos = latestVideosRes?.success ? latestVideosRes.data.items : [];
  const topRatedVideos = topRatedVideosRes?.success ? topRatedVideosRes.data.items : [];

  return (
    <html lang="vi">
      <head>
        {/* Render custom head html from settings */}
        {settings?.custom_head_html && (
          <script dangerouslySetInnerHTML={{ __html: settings.custom_head_html }} />
        )}

        {settings?.ga_code && (
          <>
            <script async src={`https://www.googletagmanager.com/gtag/js?id=${settings.ga_code}`}></script>
            <script
              dangerouslySetInnerHTML={{
                __html: `
                  window.dataLayer = window.dataLayer || [];
                  function gtag(){dataLayer.push(arguments);}
                  gtag('js', new Date());
                  gtag('config', '${settings.ga_code}');
                `,
              }}
            />
          </>
        )}
      </head>
      <body className={`${inter.variable} ${inter.className} bg-gray-50 text-gray-900 dark:bg-gray-950 dark:text-gray-100 min-h-screen flex flex-col`}>
        <Header />


        <div className="flex-grow flex flex-col md:flex-row max-w-[1800px] mx-auto w-full px-3 sm:px-4 lg:px-5 py-6 gap-6">
          {/* Nội dung chính */}
          <main className="flex-1 min-w-0">
            {children}
          </main>

          {/* Sidebar Phải */}
          <aside className="hidden xl:block w-[300px] flex-shrink-0 space-y-6">

            {/* Quảng cáo Sidebar Right */}
            <div>
              <AdSlot position="sidebar_right" ads={ads} />
            </div>


            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4 border-b pb-2 flex items-center justify-between">
                <span className="border-l-4 border-blue-600 pl-2">Phim Xem Nhiều</span>
                <Link 
                  href="/phim?sort=view" 
                  className="text-xs text-blue-700 hover:text-blue-800 hover:underline font-medium"
                  aria-label="Xem thêm phim xem nhiều"
                >
                  Xem thêm
                </Link>
              </h3>
              <div className="space-y-4">
                {hotVideos.map((v: any, index: number) => (
                  <Link key={v.id} href={`/phim/${v.slug}`} className="flex gap-3 group">
                    <div className="relative w-24 aspect-video flex-shrink-0 overflow-hidden rounded bg-gray-200 dark:bg-gray-700">
                      <Image
                        src={getImageUrl(v.thumb || v.poster)}
                        alt={v.title}
                        fill
                        sizes="96px"
                        className="object-cover transition-transform group-hover:scale-110"
                      />
                      <span className="absolute top-0 left-0 bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-br z-10">{index + 1}</span>
                    </div>
                    <div className="flex flex-col flex-1 py-1">
                      <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 line-clamp-2 group-hover:text-blue-700 transition-colors" title={v.title}>{v.title}</h4>
                      <span className="text-xs text-gray-600 dark:text-gray-400 mt-auto">{v.views?.toLocaleString()} lượt xem</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>



            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4 border-b pb-2 flex items-center justify-between">
                <span className="border-l-4 border-red-600 pl-2">Phim Mới Nhất</span>
                <Link 
                  href="/phim?sort=latest" 
                  className="text-xs text-blue-700 hover:text-blue-800 hover:underline font-medium"
                  aria-label="Xem thêm phim mới nhất"
                >
                  Xem thêm
                </Link>
              </h3>
              <div className="space-y-4">
                {latestVideos.map((v: any) => (
                  <Link key={v.id} href={`/phim/${v.slug}`} className="flex gap-3 group">
                    <div className="relative w-24 aspect-video flex-shrink-0 overflow-hidden rounded bg-gray-200 dark:bg-gray-700">
                      <Image
                        src={getImageUrl(v.thumb || v.poster)}
                        alt={v.title}
                        fill
                        sizes="96px"
                        className="object-cover transition-transform group-hover:scale-110"
                      />
                    </div>
                    <div className="flex flex-col flex-1 py-1">
                      <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 line-clamp-2 group-hover:text-red-700 transition-colors" title={v.title}>{v.title}</h4>
                      {v.year > 0 && <span className="text-xs text-gray-600 dark:text-gray-400 mt-auto">Năm: {v.year}</span>}
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4 border-b pb-2 flex items-center justify-between">
                <span className="border-l-4 border-green-700 pl-2">Đánh Giá Cao</span>
                <Link 
                  href="/phim?sort=likes" 
                  className="text-xs text-blue-700 hover:text-blue-800 hover:underline font-medium"
                  aria-label="Xem thêm phim đánh giá cao"
                >
                  Xem thêm
                </Link>
              </h3>
              <div className="space-y-4">
                {topRatedVideos.map((v: any) => {
                  const likes = Math.max(0, parseInt(String(v.likes ?? 0), 10) || 0);
                  const dislikes = Math.max(0, parseInt(String(v.dislikes ?? 0), 10) || 0);
                  const total = likes + dislikes;
                  const score = total > 0 ? Math.round((likes / total) * 100) / 10 : null;
                  return (
                    <Link key={v.id} href={`/phim/${v.slug}`} className="flex gap-3 group">
                      <div className="relative w-24 aspect-video flex-shrink-0 overflow-hidden rounded bg-gray-200 dark:bg-gray-700">
                        <Image
                          src={getImageUrl(v.thumb || v.poster)}
                          alt={v.title}
                          fill
                          sizes="96px"
                          className="object-cover transition-transform group-hover:scale-110"
                        />
                        {score !== null && (
                          <span className="absolute bottom-0 left-0 right-0 bg-black/75 text-white text-[10px] font-bold py-0.5 text-center">
                            {score}/10
                          </span>
                        )}
                      </div>
                      <div className="flex flex-col flex-1 py-1">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 line-clamp-2 group-hover:text-green-700 transition-colors" title={v.title}>{v.title}</h4>
                        <span className="text-xs text-green-700 dark:text-green-500 mt-auto font-medium" title={score !== null ? `${likes} thích / ${dislikes} không thích (tỷ lệ ≈ ${Math.round((likes / total) * 100)}%)` : undefined}>
                          {score !== null ? `★ ${score}/10` : 'Chưa có đánh giá'}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          </aside>
        </div>

        <Footer />

        {/* Render custom body html from settings */}
        {settings?.custom_body_html && (
          <div dangerouslySetInnerHTML={{ __html: settings.custom_body_html }} />
        )}
      </body>
    </html>
  );
}
