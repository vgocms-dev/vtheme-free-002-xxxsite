export default function TaxonomyLoading() {
  return (
    <div>
      <div className="h-9 w-64 skeleton rounded-lg mb-8"></div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-6">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="space-y-3">
            <div className="aspect-video skeleton rounded-lg"></div>
            <div className="h-4 w-3/4 skeleton rounded"></div>
          </div>
        ))}
      </div>
    </div>
  );
}
