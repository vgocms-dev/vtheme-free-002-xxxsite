const baseUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3000';

export async function GET() {
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>${baseUrl}/sitemap-phim.xml</loc>
    </sitemap>
    <sitemap>
        <loc>${baseUrl}/sitemap-the-loai.xml</loc>
    </sitemap>
    <sitemap>
        <loc>${baseUrl}/sitemap-ngoi-sao.xml</loc>
    </sitemap>
</sitemapindex>`;

    return new Response(xml, {
        headers: {
            'Content-Type': 'application/xml',
            'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=59',
        },
    });
}
