import { Metadata } from 'next';
import { SeoData } from './types';

export function constructMetadata(
    seo: SeoData | undefined | null,
    fallbackTitle: string = 'Video Site',
    fallbackDescription: string = 'Khám phá hàng ngàn bộ phim hay, cập nhật liên tục.',
    fallbackImages: any[] = [],
    fallbackOgType: string = 'website'
): Metadata {
    if (!seo) {
        return {
            title: fallbackTitle,
            description: fallbackDescription,
            openGraph: {
                title: fallbackTitle,
                description: fallbackDescription,
                images: fallbackImages,
                type: fallbackOgType as any,
            },
            twitter: {
                card: 'summary_large_image',
                title: fallbackTitle,
                description: fallbackDescription,
                images: fallbackImages,
            }
        };
    }

    const images = seo.og_image ? [{ url: seo.og_image }] : fallbackImages;

    return {
        title: seo.title || fallbackTitle,
        description: seo.description || fallbackDescription,
        keywords: seo.keywords,
        openGraph: {
            title: seo.og_title || seo.title || fallbackTitle,
            description: seo.og_description || seo.description || fallbackDescription,
            images: images,
            type: (seo.og_type as any) || fallbackOgType,
        },
        twitter: {
            card: (seo.twitter_card as any) || 'summary_large_image',
            title: seo.og_title || seo.title || fallbackTitle,
            description: seo.og_description || seo.description || fallbackDescription,
            images: images,
        }
    };
}
