import { API_BASE_URL, SITE_SLUG } from './config';
import { SiteSettings, VideoListResponse, VideoDetailResponse, MenuResponse, TaxonomyGroups, HotVideoResult, VideoItem } from './types';

// Helper for fetch wrapper
async function fetchAPI<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint}`;

  // Next.js 16 cache setup via fetch options if needed, though 'use cache' is preferred for App Router components
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    // Default config suitable for SSR/ISR
    next: { revalidate: 60, ...options.next },
  });

  if (!res.ok) {
    let errorMsg = `API Error: ${res.statusText}`;
    try {
      const errorData = await res.json();
      errorMsg = errorData.error || errorMsg;
    } catch (e) {
      // Ignore
    }
    throw new Error(errorMsg);
  }

  return res.json() as Promise<T>;
}

// Site API Client

export async function getSiteSettings(): Promise<{ success: boolean; data: SiteSettings }> {
  return fetchAPI<{ success: boolean; data: SiteSettings }>(`/api/sites/${SITE_SLUG}/settings`, {
    next: { revalidate: 3600 } // Cache 1 hour
  });
}

export async function getSiteVideos(params: Record<string, string | number> = {}): Promise<VideoListResponse> {
  const queryParams = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      queryParams.append(key, String(value));
    }
  });

  const queryString = queryParams.toString();
  const url = `/api/sites/${SITE_SLUG}/videos${queryString ? `?${queryString}` : ''}`;

  return fetchAPI<VideoListResponse>(url, {
    next: { revalidate: 300 } // 5 mins
  });
}

export async function getSiteVideoDetail(slug: string): Promise<VideoDetailResponse> {
  return fetchAPI<VideoDetailResponse>(`/api/sites/${SITE_SLUG}/videos/${slug}`, {
    next: { revalidate: 1800 } // 30 mins
  });
}

export async function getSiteRelatedVideos(slug: string, limit = 12): Promise<{ success: boolean; data: { items: VideoItem[] } }> {
  return fetchAPI<{ success: boolean; data: { items: VideoItem[] } }>(`/api/sites/${SITE_SLUG}/videos/${slug}/related?limit=${limit}`, {
    next: { revalidate: 600 } // 10 mins
  });
}

export interface TopViewsPeriod {
  items: VideoItem[];
  total_records: number;
}

export async function getSiteTopViews(limit = 12): Promise<{
  success: boolean;
  data: { day: TopViewsPeriod; week: TopViewsPeriod; month: TopViewsPeriod };
}> {
  return fetchAPI(`/api/sites/${SITE_SLUG}/videos/top-views?limit=${limit}`, {
    next: { revalidate: 10800 } // 3h
  });
}

export async function getSiteTaxonomies(type?: string): Promise<{ success: boolean; data: TaxonomyGroups }> {
  const url = `/api/sites/${SITE_SLUG}/taxonomies${type ? `?type=${type}` : ''}`;
  return fetchAPI<{ success: boolean; data: TaxonomyGroups }>(url, {
    next: { revalidate: 3600 } // 1 hour
  });
}

export async function getSiteAds(position?: string): Promise<any> {
  const url = `/api/sites/${SITE_SLUG}/ads${position ? `?position=${position}` : ''}`;
  return fetchAPI<any>(url, {
    next: { revalidate: 3600 }
  }).catch(() => null); // Return null on error so it doesn't break the page
}

export async function getSiteMenu(menuSlug: string): Promise<MenuResponse | null> {
  return fetchAPI<MenuResponse>(`/api/sites/${SITE_SLUG}/menus/${menuSlug}`, {
    next: { revalidate: 86400 } // 24 hours
  }).catch(() => null);
}

// Global API Client

export async function postView(videoId: number): Promise<{ success: boolean; views: number }> {
  return fetchAPI<{ success: boolean; views: number }>(`/api/v1/videos/${videoId}/view`, {
    method: 'POST',
    cache: 'no-store'
  });
}

export async function postRate(videoId: number, action: 'like' | 'dislike'): Promise<{ success: boolean; likes: number; dislikes: number }> {
  const formData = new FormData();
  formData.append('action', action);

  const res = await fetch(`${API_BASE_URL}/api/v1/videos/${videoId}/rate`, {
    method: 'POST',
    body: formData,
    cache: 'no-store'
  });

  if (!res.ok) {
    let errorMsg = 'Rating failed';
    try {
      const errData = await res.json();
      errorMsg = errData.error || errorMsg;
    } catch (e) {
      // Ignore
    }
    throw new Error(errorMsg);
  }
  return res.json();
}

export async function getPersonDetail(slug: string, page: string = '1'): Promise<any> {
  return fetchAPI<any>(`/api/sites/${SITE_SLUG}/persons/${slug}?page=${page}`, {
    next: { revalidate: 3600 }
  });
}

export async function getSiteActors(page: string = '1', q: string = ''): Promise<any> {
  const query = new URLSearchParams();
  if (page) query.append('page', page);
  if (q) query.append('q', q);
  return fetchAPI<any>(`/api/sites/${SITE_SLUG}/actors?${query.toString()}`, {
    next: { revalidate: 3600 }
  });
}

export async function getSiteDirectors(page: string = '1', q: string = ''): Promise<any> {
  const query = new URLSearchParams();
  if (page) query.append('page', page);
  if (q) query.append('q', q);
  return fetchAPI<any>(`/api/sites/${SITE_SLUG}/directors?${query.toString()}`, {
    next: { revalidate: 3600 }
  });
}

export async function getSiteStars(page: string = '1', q: string = '', role: string = ''): Promise<any> {
  const query = new URLSearchParams();
  if (page) query.append('page', page);
  if (q) query.append('q', q);
  if (role) query.append('role', role);
  return fetchAPI<any>(`/api/sites/${SITE_SLUG}/stars?${query.toString()}`, {
    next: { revalidate: 3600 }
  });
}

export async function getTagSeo(slug: string): Promise<{ slug: string; name: string; seo_title: string; seo_keywords: string }> {
  return fetchAPI<{ slug: string; name: string; seo_title: string; seo_keywords: string }>(`/api/v1/seo/tag/${slug}`, {
    next: { revalidate: 3600 }
  });
}

// Global Dashboard/Home API
export async function getHotVideos(period: string = 'week'): Promise<HotVideoResult[]> {
  return fetchAPI<HotVideoResult[]>(`/api/v1/videos/hot?period=${period}`, {
    next: { revalidate: 900 } // 15 mins
  }).catch(() => []);
}

export async function getLatestVideos(): Promise<VideoItem[]> {
  return fetchAPI<VideoItem[]>(`/api/v1/videos/latest`, {
    next: { revalidate: 600 } // 10 mins
  }).catch(() => []);
}

export async function getTopRatedVideos(): Promise<VideoItem[]> {
  return fetchAPI<VideoItem[]>(`/api/v1/videos/top-rated`, {
    next: { revalidate: 900 } // 15 mins
  }).catch(() => []);
}
