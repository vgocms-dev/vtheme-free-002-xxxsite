'use client';

import { useRouter } from 'next/navigation';
import { useRef } from 'react';

export default function StarFilterForm({ defaultQ, defaultRole }: { defaultQ: string, defaultRole: string }) {
    const formRef = useRef<HTMLFormElement>(null);

    const handleSubmit = () => {
        if (formRef.current) {
            formRef.current.submit();
        }
    };

    return (
        <form ref={formRef} action="/ngoi-sao" className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <select
                name="role"
                defaultValue={defaultRole}
                className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
                onChange={handleSubmit}
            >
                <option value="">Tất cả vai trò</option>
                <option value="actor">Diễn viên</option>
                <option value="director">Đạo diễn</option>
            </select>

            <div className="relative w-full sm:w-64">
                <input
                    type="text"
                    name="q"
                    defaultValue={defaultQ}
                    placeholder="Tìm theo tên..."
                    className="w-full px-4 py-2 pr-10 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button type="submit" className="absolute right-3 top-2.5 text-gray-400 hover:text-blue-500">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                </button>
            </div>
        </form>
    );
}
