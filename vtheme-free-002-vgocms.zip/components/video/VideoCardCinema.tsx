import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';
import { Clapperboard } from 'lucide-react';

export default function VideoCardCinema({ video, priority }: { video: VideoItem; priority?: boolean }) {
  return (
    <Link
      href={`/phim/${video.slug}`}
      className="group block rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl border-2 border-amber-500/40 hover:border-amber-400 dark:border-amber-500/50 dark:hover:border-amber-400 shadow-lg shadow-amber-900/10 dark:shadow-amber-500/5"
    >
      {/* Image area - cinema style */}
      <div className="relative aspect-video w-full overflow-hidden rounded-t-xl bg-gray-900">
        <Image
          src={getImageUrl(video.thumb || video.poster)}
          alt={video.title}
          fill
          sizes="(max-width: 640px) 100vw, 480px"
          quality={80}
          priority={priority}
          fetchPriority={priority ? "high" : undefined}
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
      </div>
      {/* Title & Original below - amber accent */}
      <div className="px-3 py-2.5">
        <h3 className="text-gray-900 dark:text-white font-bold text-sm leading-snug">
          {video.title}
          {video.year > 0 && (
            <span className="text-amber-800 dark:text-amber-400 font-semibold text-xs ml-0.5">({video.year})</span>
          )}
        </h3>
        {video.original_name && (
          <span className="text-gray-700 dark:text-gray-400 text-[11px] mt-0.5 block font-medium">{video.original_name}</span>
        )}
      </div>
    </Link>
  );
}
