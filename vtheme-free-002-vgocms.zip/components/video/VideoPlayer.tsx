'use client';

import { useState, useEffect, useRef } from 'react';
import { EpisodeInput } from '@/lib/types';
import { Film } from 'lucide-react';

interface VideoPlayerProps {
  episode?: EpisodeInput;
  /** Khi true = không có tập nào; khi false/undefined = có tập nhưng chưa chọn */
  hasEpisodes?: boolean;
}

export default function VideoPlayer({ episode, hasEpisodes = true }: VideoPlayerProps) {
  const [isLoading, setIsLoading] = useState(false);
  const loadTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (episode?.link_embed) {
      setIsLoading(true);
      if (loadTimeoutRef.current) clearTimeout(loadTimeoutRef.current);
      loadTimeoutRef.current = setTimeout(() => {
        setIsLoading(false);
        loadTimeoutRef.current = null;
      }, 4000);
      return () => {
        if (loadTimeoutRef.current) clearTimeout(loadTimeoutRef.current);
      };
    } else {
      setIsLoading(false);
    }
  }, [episode?.slug, episode?.link_embed]);

  const handleIframeLoad = () => {
    if (loadTimeoutRef.current) {
      clearTimeout(loadTimeoutRef.current);
      loadTimeoutRef.current = null;
    }
    setIsLoading(false);
  };

  if (!episode || !episode.link_embed) {
    const isUpdating = hasEpisodes === false;
    return (
      <div
        className={`w-full aspect-video relative flex items-center justify-center rounded-lg shadow-lg overflow-hidden ${isUpdating
            ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
            : 'bg-gray-900'
          }`}
      >
        {isUpdating && (
          <>
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.08)_0%,transparent_70%)]" />
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
          </>
        )}
        <div className="relative flex flex-col items-center justify-center gap-4 px-6">
          <div
            className={`flex items-center justify-center rounded-2xl transition-colors ${isUpdating
                ? 'bg-blue-500/10 p-5 ring-1 ring-blue-500/20'
                : 'bg-gray-800 p-5'
              }`}
          >
            <Film
              className={`w-14 h-14 sm:w-16 sm:h-16 ${isUpdating ? 'text-blue-400' : 'text-gray-500'
                }`}
              strokeWidth={1.5}
            />
          </div>
          <div className="text-center space-y-1">
            <p
              className={`text-lg sm:text-xl font-semibold ${isUpdating ? 'text-gray-200' : 'text-gray-400'
                }`}
            >
              {isUpdating ? 'Phim đang cập nhật' : 'Chọn một tập để xem'}
            </p>
            {isUpdating && (
              <p className="text-sm text-gray-500">Vui lòng quay lại sau để xem phim</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full aspect-video bg-black relative rounded-lg overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-gray-950/95">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="mt-3 text-sm text-gray-400">Đang tải {episode.name}...</p>
        </div>
      )}
      <iframe
        src={episode.link_embed}
        className="w-full h-full border-none"
        allowFullScreen
        sandbox="allow-scripts allow-same-origin allow-presentation"
        title={`Xem phim - ${episode.name}`}
        onLoad={handleIframeLoad}
      />
    </div>
  );
}
