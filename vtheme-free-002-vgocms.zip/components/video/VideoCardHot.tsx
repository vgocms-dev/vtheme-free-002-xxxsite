import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';

export default function VideoCardHot({ video, rank, priority }: { video: VideoItem; rank: number; priority?: boolean }) {
  const imgSrc = getImageUrl(video.thumb || video.poster);
  
  const formats = video.formats || [];
  const formatLabels = formats.slice(0, 2).map((f) => f.lang_name || f.name);
  const isCompleted = video.release_status === 'completed';
  const episodeInfo =
    (video.episode_count ?? 0) > 0
      ? isCompleted
        ? `Tập (${video.current_episode ?? 0}/${video.episode_count ?? 0})`
        : `Tập ${video.current_episode ?? video.episode_count ?? 0}`
      : `FULL`;

  return (
    <Link
      href={`/phim/${video.slug}`}
      className="group block rounded-lg overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:opacity-95 bg-transparent"
    >
      {/* Poster - clean, minimal overlay */}
      <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-gray-800">
        <Image
          src={imgSrc}
          alt={video.title}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          quality={75}
          priority={priority}
          fetchPriority={priority ? "high" : undefined}
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      {/* Text section - rank trái, name phải */}
      <div className="pt-2.5 px-0.5 flex gap-2 items-start">
        {/* Số thứ tự - trái ngoài */}
        <div className="text-5xl font-black text-amber-800 dark:text-amber-500 leading-none flex-shrink-0 drop-shadow-sm">
          {rank}
        </div>
        {/* Name bên phải */}
        <div className="min-w-0 flex-1">
          <h3 className="text-gray-900 dark:text-white font-bold text-sm leading-snug line-clamp-2">
            {video.title}
          </h3>
        </div>
      </div>
    </Link>
  );
}
