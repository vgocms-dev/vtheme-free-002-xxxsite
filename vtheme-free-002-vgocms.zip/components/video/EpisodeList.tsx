"use client";

import { useMemo, useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { ServerEpisode, EpisodeInput } from "@/lib/types";
import { getImageUrl } from "@/lib/utils";

interface EpisodeListProps {
  servers: ServerEpisode[];
  currentEpisode?: EpisodeInput;
  onSelectEpisode: (episode: EpisodeInput) => void;
  fallbackThumb?: string;
}

const CHUNK_SIZE = 50;

export default function EpisodeList({
  servers,
  currentEpisode,
  onSelectEpisode,
  fallbackThumb = "",
}: EpisodeListProps) {
  const [activeServerId, setActiveServerId] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [chunkIndex, setChunkIndex] = useState(0);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [isExpanded, setIsExpanded] = useState(false);

  // Khởi tạo active server
  useEffect(() => {
    if (servers.length > 0 && !activeServerId) {
      setActiveServerId(servers[0].server_id);
    }
  }, [servers, activeServerId]);

  const activeServer = useMemo(
    () => servers.find((s) => s.server_id === activeServerId) || servers[0],
    [servers, activeServerId]
  );

  const rawEpisodes = activeServer?.server_data || [];

  const { filtered, chunks, totalCount } = useMemo(() => {
    let naturalSorted = [...rawEpisodes];

    const filtered = naturalSorted.filter((ep) =>
      ep.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const chunkCount = Math.ceil(filtered.length / CHUNK_SIZE);
    const chunks = Array.from({ length: chunkCount }, (_, i) => {
      const start = i * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, filtered.length);
      const items = filtered.slice(start, end);
      return {
        label: `Tập ${items[0].name} - ${items[items.length - 1].name}`,
        start,
        end,
        items
      };
    });

    const totalCount = naturalSorted.length;

    return { filtered, chunks, totalCount };
  }, [rawEpisodes, searchQuery]);

  const safeChunkIndex = Math.min(chunkIndex, Math.max(0, chunks.length - 1));
  const currentChunk = chunks[safeChunkIndex];

  const visibleEpisodes = useMemo(() => {
    const base = currentChunk ? currentChunk.items : filtered;
    return sortOrder === 'desc' ? [...base].reverse() : base;
  }, [currentChunk, filtered, sortOrder]);

  const isSameEpisode = (a?: EpisodeInput, b?: EpisodeInput) =>
    a && b && a.slug === b.slug && a.link_embed === b.link_embed;
  const currentIndex = currentEpisode ? filtered.findIndex((ep: EpisodeInput) => isSameEpisode(ep, currentEpisode)) : -1;

  useEffect(() => {
    if (currentIndex >= 0) {
      const targetChunk = Math.floor(currentIndex / CHUNK_SIZE);
      setChunkIndex(targetChunk);
    }
  }, [currentEpisode?.slug, currentEpisode?.link_embed, currentIndex]);

  if (!activeServer) return null;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
      <div className="bg-gray-100 dark:bg-gray-700 flex flex-wrap border-b border-gray-200 dark:border-gray-600">
        {servers.map((server: ServerEpisode) => (
          <button
            key={server.server_id}
            onClick={() => {
              setActiveServerId(server.server_id);
              setChunkIndex(0);
            }}
            className={`px-4 py-3 text-sm font-medium transition-colors ${(activeServerId || servers[0]?.server_id) === server.server_id
              ? 'bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 border-t-2 border-t-blue-500'
              : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 hover:text-gray-900 dark:hover:text-white'
              }`}
          >
            {server.server_name}
          </button>
        ))}
      </div>

      <div className="p-4 space-y-4">
        {/* Thanh công cụ: Tìm kiếm + Sắp xếp (ẩn khi < 10 tập) + Chế độ hiển thị (luôn hiện) */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
            {totalCount >= 10 && (
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Tìm tập phim..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setChunkIndex(0);
                  }}
                  className="w-full pl-9 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            )}

            <div className={`flex items-center gap-2 ${totalCount < 10 ? 'w-full justify-end' : ''}`}>
              {totalCount >= 10 && (
                <button
                  type="button"
                  onClick={() => {
                    setSortOrder((v: 'asc' | 'desc') => (v === 'asc' ? 'desc' : 'asc'));
                  }}
                  className="whitespace-nowrap flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600 text-sm font-medium transition-colors"
                  title={sortOrder === 'asc' ? 'Đổi sang lớn → nhỏ' : 'Đổi sang nhỏ → lớn'}
                >
                  {sortOrder === 'asc' ? (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" /></svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                  )}
                  <span>{sortOrder === 'asc' ? 'Nhỏ→Lớn' : 'Lớn→Nhỏ'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsExpanded(!isExpanded)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-sm font-medium transition-colors ${isExpanded
                  ? 'bg-blue-50 border-blue-200 text-blue-600 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-400'
                  : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600'
                  }`}
                title={isExpanded ? 'Chế độ rút gọn' : 'Chế độ mở rộng (Thumbnails)'}
              >
                {isExpanded ? (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" /></svg>
                ) : (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>
                )}
                <span>{isExpanded ? 'Rút gọn' : 'Mở rộng'}</span>
              </button>

              {chunks.length > 1 && (
                <div className="relative flex-1 sm:flex-initial">
                  <select
                    value={safeChunkIndex}
                    onChange={(e) => setChunkIndex(parseInt(e.target.value, 10))}
                    className="w-full appearance-none bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-3 py-2 pr-8 outline-none transition-colors"
                  >
                    {chunks.map((chunk: any, i: number) => (
                      <option key={i} value={i}>
                        {chunk.label}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700 dark:text-gray-300">
                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" /></svg>
                  </div>
                </div>
              )}
            </div>
          </div>

          {(searchQuery || chunks.length > 1) && (
            <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400 px-1">
              <span>Hiển thị {visibleEpisodes.length} / {filtered.length} tập</span>
              {searchQuery && <span>Tìm thấy {filtered.length} tập</span>}
            </div>
          )}
        </div>

        {/* Danh sách tập */}
        <div className={isExpanded
          ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4"
          : "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2"
        }>
          {visibleEpisodes.length > 0 ? (
            visibleEpisodes.map((ep: EpisodeInput) => {
              const isActive = currentEpisode?.slug === ep.slug && currentEpisode?.link_embed === ep.link_embed;

              if (isExpanded) {
                return (
                  <button
                    key={`${activeServer.server_id}-${ep.slug}`}
                    onClick={() => onSelectEpisode(ep)}
                    className={`group relative flex flex-col gap-2 rounded-lg overflow-hidden border transition-all ${isActive
                      ? 'border-blue-500 ring-2 ring-blue-500/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-blue-400 dark:hover:border-blue-500'
                      }`}
                  >
                    <div className="relative aspect-video w-full bg-gray-100 dark:bg-gray-900 overflow-hidden">
                      <Image
                        src={getImageUrl(ep.thumb || fallbackThumb)}
                        alt={ep.name}
                        fill
                        sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                        className={`object-cover transition-transform duration-300 ${isActive ? 'scale-105' : 'group-hover:scale-105'}`}
                      />
                      <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                        <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white">
                          <svg className="w-6 h-6 ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                        </div>
                      </div>
                    </div>
                    <div className={`py-2 px-3 text-sm font-medium text-center truncate ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-gray-700 dark:text-gray-200'}`}>
                      {ep.name}
                    </div>
                  </button>
                );
              }

              return (
                <button
                  key={`${activeServer.server_id}-${ep.slug}`}
                  onClick={() => onSelectEpisode(ep)}
                  className={`py-2 px-3 text-sm rounded transition-all truncate text-center font-medium shadow-sm hover:shadow-md ${isActive
                    ? 'bg-blue-600 text-white shadow-blue-200 dark:shadow-none scale-105 z-10'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 hover:text-blue-600 dark:hover:text-blue-400'
                    }`}
                  title={ep.name}
                >
                  {ep.name}
                </button>
              );
            })
          ) : (
            <div className="col-span-full text-center py-10 bg-gray-50 dark:bg-gray-800/50 rounded-lg border-2 border-dashed border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400">
              Không tìm thấy tập phù hợp
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
