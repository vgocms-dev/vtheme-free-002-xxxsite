import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { VideoItem } from '@/lib/types';
import { getImageUrl } from '@/lib/utils';

export default function VideoCard({ video, priority }: { video: VideoItem; priority?: boolean }) {
  const imgSrc = getImageUrl(video.thumb || video.poster);
  return (
    <Link
      href={`/phim/${video.slug}`}
      className="group block rounded-lg overflow-hidden shadow-md transition-transform hover:-translate-y-1 hover:shadow-xl"
    >
      {/* Image area - rounded, có nền */}
      <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-white dark:bg-gray-800">
        <Image
          src={imgSrc}
          alt={video.title}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          quality={75}
          priority={priority}
          fetchPriority={priority ? "high" : undefined}
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-3">
          {/* Metadata row: Country • Category - Phải sang trái, dưới lên trên */}
          <div className="flex flex-row-reverse flex-wrap-reverse items-center text-[11px] text-gray-300 font-medium gap-y-1 mt-0.5 w-full">
            {video.categories && video.categories.map((cat, idx) => (
              <React.Fragment key={`cat-${cat.id}`}>
                <span className="whitespace-nowrap hover:text-white transition-colors">
                  {cat.lang_name || cat.name}
                </span>
                {idx < (video.categories?.length || 0) - 1 && <span className="text-gray-600 mx-1">•</span>}
                {idx === (video.categories?.length || 0) - 1 && (video.countries?.length || 0) > 0 && (
                  <span className="text-gray-600 mx-1">•</span>
                )}
              </React.Fragment>
            ))}

            {video.countries && video.countries.map((country, idx) => (
              <React.Fragment key={`country-${country.id}`}>
                <span className="whitespace-nowrap hover:text-white transition-colors">
                  {country.lang_name || country.name}
                </span>
                {idx < (video.countries?.length || 0) - 1 && <span className="text-gray-600 mx-1">•</span>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Chỉ Title & Original name dưới hình - không cắt, không nền */}
      <div className="px-1 py-1.5 bg-transparent">
        <h3 className="text-gray-900 dark:text-white font-semibold text-sm leading-snug">
          {video.title}
          {video.year > 0 && (
            <span className="text-gray-700 dark:text-gray-400 font-medium text-xs ml-0.5">
              ({video.year})
            </span>
          )}
        </h3>
      </div>
    </Link>
  );
}
