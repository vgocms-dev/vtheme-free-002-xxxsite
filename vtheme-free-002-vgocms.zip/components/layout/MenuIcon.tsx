import * as LucideIcons from 'lucide-react';

function toPascalCase(name: string): string {
  return name
    .split('-')
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase())
    .join('');
}

export default function MenuIcon({ name, className = 'w-4 h-4' }: { name?: string; className?: string }) {
  if (!name || !name.trim()) return null;
  const pascal = toPascalCase(name.trim());
  const Icon = (LucideIcons as unknown as Record<string, React.ComponentType<{ className?: string; size?: number }>>)[pascal];
  if (!Icon) return null;
  return <Icon className={className} size={16} />;
}
