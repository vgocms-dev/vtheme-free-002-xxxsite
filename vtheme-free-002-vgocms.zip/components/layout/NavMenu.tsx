import Link from 'next/link';
import { MenuItem } from '@/lib/types';
import MenuIcon from './MenuIcon';

export default function NavMenu({ items }: { items: MenuItem[] }) {
  if (!items || items.length === 0) return null;

  const renderItem = (item: MenuItem) => {
    const isExternal = item.target === '_blank';
    const content = (
      <span className="flex items-center gap-1.5 hover:text-blue-500 transition-colors py-2 px-3">
        <MenuIcon name={item.icon} className="w-4 h-4 flex-shrink-0 opacity-80" />
        {item.label}
      </span>
    );

    const link = isExternal ? (
      <a href={item.url} target="_blank" rel="noopener noreferrer" key={item.id}>
        {content}
      </a>
    ) : (
      <Link href={item.url} key={item.id}>
        {content}
      </Link>
    );

    if (item.children && item.children.length > 0) {
      return (
        <div key={item.id} className="group relative">
          {link}
          <div className="absolute left-0 top-full hidden group-hover:block bg-white dark:bg-gray-800 shadow-lg rounded-md min-w-[180px] z-50 py-1">
            {item.children.map(child => (
              <div key={child.id} className="px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700">
                {child.target === '_blank' ? (
                  <a href={child.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 w-full">
                    <MenuIcon name={child.icon} className="w-3.5 h-3.5 flex-shrink-0 opacity-70" />
                    {child.label}
                  </a>
                ) : (
                  <Link href={child.url} className="flex items-center gap-1.5 block w-full">
                    <MenuIcon name={child.icon} className="w-3.5 h-3.5 flex-shrink-0 opacity-70" />
                    {child.label}
                  </Link>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }


    return <div key={item.id}>{link}</div>;
  };

  return (
    <nav className="flex items-center gap-4 relative">
      {items.map(renderItem)}
    </nav>
  );
}
