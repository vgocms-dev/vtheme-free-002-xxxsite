import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Set up headers for security best practices
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=(), browsing-topics=()',
          },
          // Basic CSP: Self, Analytics, Video embeds
          // Allows standard Next.js inline styles/scripts and Google Analytics/AdSense domains if needed
          // Can be refined further based on specific ad/embed providers
          {
            key: 'Content-Security-Policy',
            value: "default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline' https://www.googletagmanager.com https://static.cloudflareinsights.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: http: https:; font-src 'self' data:; connect-src 'self' http: https: https://cloudflareinsights.com; frame-src 'self' http: https:;",
          }
        ],
      },
    ];
  },
  // If backend API is not strictly on localhost, we might want proxy or external image domains
  images: {
    dangerouslyAllowLocalIP: process.env.NODE_ENV === 'development',
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
      {
        protocol: 'http',
        hostname: '**',
      }
    ],
  },
  experimental: {
    // Next 16 turbopack optimizations etc
  }
};

export default nextConfig;
